import 'package:flutter/material.dart';

class PREVIEW extends StatelessWidget {
  const PREVIEW({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          "Previews",
          style: TextStyle(
              color: Colors.white, fontSize: 25, fontWeight: FontWeight.bold),
        ),
        Container(
          color: Colors.transparent,
          width: double.infinity,
          height: 100,
          child: ListView(
            padding: const EdgeInsets.all(6),
            scrollDirection: Axis.horizontal,
            children: const [
              CircleAvatar(
                radius: 50,
                backgroundImage:
                    AssetImage("assets/images/stranger_things.jpg"),
              ),
              CircleAvatar(
                radius: 50,
                backgroundImage:
                    AssetImage("assets/images/thirteen_reasons.jpg"),
              ),
              CircleAvatar(
                radius: 50,
                backgroundImage: AssetImage("assets/images/sintel.jpg"),
              ),
              CircleAvatar(
                radius: 50,
                backgroundImage: AssetImage("assets/images/carole.jpg"),
              ),
              CircleAvatar(
                radius: 50,
                backgroundImage: AssetImage("assets/images/witcher.jpg"),
              ),
              CircleAvatar(
                radius: 50,
                backgroundImage:
                    AssetImage("assets/images/umbrella_academy.jpg"),
              ),
            ],
          ),
        )
      ],
    );
  }
}

import 'package:flutter/material.dart';

class DOWNLOADS extends StatelessWidget {
  const DOWNLOADS({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      child: const Center(
        child: Text("DOWNLOADS"),
      ),
    );
  }
}

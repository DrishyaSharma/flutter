import 'package:flutter/material.dart';
import 'package:flutter_application_4/screen/comingSoon.dart';
import 'package:flutter_application_4/screen/downloads.dart';
import 'package:flutter_application_4/screen/homePage.dart';
import 'package:flutter_application_4/screen/more.dart';
import 'package:flutter_application_4/screen/search.dart';

class NavBar extends StatefulWidget {
  const NavBar({super.key});

  @override
  State<NavBar> createState() => _NavBarState();
}

class _NavBarState extends State<NavBar> {
  int currentIndexs = 0;
  final List screens = [
    const homePage(),
    const SEARCH(),
    const DOWNLOADS(),
    const MORE(),
    const COMINGSOON()
  ];
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        //extendBodyBehindAppBar: true,
        //backgroundColor: Colors.black,
        // appBar: AppBar(
        //   backgroundColor: Colors.transparent,
        // ),

        body: screens[currentIndexs],
        bottomNavigationBar: BottomNavigationBar(
            currentIndex: currentIndexs,
            type: BottomNavigationBarType.fixed,
            onTap: (value) {
              setState(() {
                currentIndexs = value;
              });
            },
            backgroundColor: Colors.black,
            //backgroundColor: Colors.white,
            unselectedItemColor: Colors.white.withOpacity(.60),
            selectedFontSize: 13,
            unselectedFontSize: 10,
            items: const [
              BottomNavigationBarItem(label: "Home", icon: Icon(Icons.home)),
              BottomNavigationBarItem(
                  label: "Search", icon: Icon(Icons.search)),
              BottomNavigationBarItem(
                  label: "Downloads", icon: Icon(Icons.download)),
              BottomNavigationBarItem(
                  label: "MORE", icon: Icon(Icons.more_vert_rounded)),
              BottomNavigationBarItem(
                  label: "Settings", icon: Icon(Icons.settings)),
            ]),
      ),
    );
  }
}

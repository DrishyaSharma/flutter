import 'package:flutter/material.dart';

class SEARCH extends StatelessWidget {
  const SEARCH({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      child: const Center(
        child: Text("SEARCH"),
      ),
    );
  }
}

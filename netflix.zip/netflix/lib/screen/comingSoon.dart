import 'package:flutter/material.dart';

class COMINGSOON extends StatelessWidget {
  const COMINGSOON({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      child: const Center(
        child: Text("COMING SOON"),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter_application_4/shared/widget/myList.dart';
import 'package:flutter_application_4/shared/widget/nf_stack.dart';
import 'package:flutter_application_4/shared/widget/preview.dart';

class homePage extends StatefulWidget {
  const homePage({super.key});

  @override
  State<homePage> createState() => _homePageState();
}

class _homePageState extends State<homePage> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
          extendBodyBehindAppBar: true,
          backgroundColor: Colors.transparent,
          appBar: AppBar(
            backgroundColor: Colors.transparent,
            leading: Image.asset("assets/images/netflix_logo0.png"),
            actions: [
              Padding(
                padding: const EdgeInsets.all(10.0),
                child: GestureDetector(
                  onTap: () {},
                  child: const Text(
                    "TV Shows",
                    style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(10.0),
                child: GestureDetector(
                  onTap: () {},
                  child: const Text(
                    "Movies",
                    style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(10.0),
                child: GestureDetector(
                  onTap: () {},
                  child: const Text("My List",
                      style:
                          TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                ),
              )
            ],
          ),
          // bottomNavigationBar: BottomNavigationBar(
          //   backgroundColor: ,
          //   items: const [
          //   BottomNavigationBarItem(label: "HOME", icon: Icon(Icons.home)),
          //   BottomNavigationBarItem(label: "SEARCH", icon: Icon(Icons.search)),
          //   //BottomNavigationBarItem(label: "COMING SOON", icon: Icon(Icons.commin)),
          //   BottomNavigationBarItem(label: "DOWNLOAD", icon: Icon(Icons.download)),
          //   BottomNavigationBarItem(label: "MORE", icon: Icon(Icons.more)),
          // ],),
          body: SingleChildScrollView(
            child: Container(
              color: Colors.black,
              width: double.infinity,
              // height: double.infinity,
              child: const Column(
                children: [NFSTACK(), PREVIEW(), MYLIST()],
              ),
            ),
          )),
    );
  }
}

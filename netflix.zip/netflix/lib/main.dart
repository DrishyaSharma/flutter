import 'package:flutter/material.dart';
import 'package:flutter_application_4/screen/bottomNav.dart';
//import 'package:netflix_app/screen/homePage.dart';

void main() {
  runApp(const MaterialApp(
    //home: homePage()
    home: NavBar(),
  ));
}
